from langchain.text_splitter import RecursiveCharacterTextSplitter

def create_chunks(documents):
    text_splitter=RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        separators=["\n\n", "\n", " ", ""]
    )
    chunks=text_splitter.split_documents(documents)
    return chunks