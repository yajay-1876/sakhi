
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferWindowMemory
from langchain.prompts import PromptTemplate

from dotenv import load_dotenv
load_dotenv()

from rag.retriever import get_retriever
from rag.llm_defination import get_llm


RAG_prompt=PromptTemplate(
    input_variables=["context","question"],
    template="""
use only supplied book context to answer the question.
Answer using only the provided context.
If the answer cannot be reasonably inferred from the context,
respond with "NOT_FOUND_IN_BOOKS".
Do not use your general knowledge.

Book Context:
{context}

Question:
{question}  

Answer:
""".strip()
)

def build_chain():
    retriever= get_retriever()
    llm=get_llm()
    memory=ConversationBufferWindowMemory(
        k=4 ,                                    # retains only the latest four exchanges
        output_key="answer",
        memory_key="chat_history",
        return_messages=True
    )
    chain=ConversationalRetrievalChain.from_llm(
        llm=llm,
        memory=memory,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
        get_chat_history=lambda history: history,           # Do not edit anything , send as it is.
        combine_docs_chain_kwargs={"prompt":RAG_prompt},
        verbose=True
    )
    return chain

def ask_question(chain, question):
    response= chain.invoke({"question":question})
    book_answer=response["answer"].strip()
    source_documents= response["source_documents"]
    print(response)
    if not source_documents or "NOT_FOUND_IN_BOOKS" in book_answer:
        llm= get_llm()
        general_response = llm.invoke(question)
        answer = f"{general_response.content}\n\nSources:\nLLM TRAINED MEMORY"
        return answer

    sources=set()
    for document in source_documents:
        source= document.metadata.get("file_name", "Unknown file")
        page=document.metadata.get("page")
        if page is not None:
            source=f"{source} , page {page+1}"
        sources.add(f"- {source}")

    source_str=""
    for s in sources:
        source_str= source_str +"\n"+s
    answer= f"{book_answer}\n\nSources:\n{source_str}"
    return answer

# if __name__ == "__main__":
#     chain= build_chain()
#     result = ask_question(
#         chain=chain,
#         question="what is capital of inida?",
#     )
#     print(result)
