from langchain_huggingface import HuggingFaceEmbeddings

def get_embeddings():
    return HuggingFaceEmbeddings(
        model_name="BAAI/bge-base-en-v1.5"
    )

# Checking Dimensionality
# embeddings= HuggingFaceEmbeddings(
#     model_name="BAAI/bge-base-en-v1.5"
# )
# vector =embeddings.embed_query("hello")
# print(len(vector))       #768
# print(vector)