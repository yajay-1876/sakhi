from rag.pinecone_store import get_vector_store


def get_retriever():
    vector_store= get_vector_store()
    return vector_store.as_retriever(
        search_type="similarity_score_threshold",
        search_kwargs={
            "k":4,
            "score_threshold":0.35
        }
    )

#def retrieve_chunks(query, k=5):
#     vector_store = get_vector_store()
#
#     docs= vector_store.similarity_search(
#         query=query,
#         k=k
#     )
#     return docs