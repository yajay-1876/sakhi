from src.backend.rag.ingest import load_pdf
from src.backend.rag.chunker import create_chunks
from src.backend.rag.pinecone_store import get_vector_store

vector_store = get_vector_store()

def process_pdf(uploaded_file, document_id, conv_id, filename):
    try:
        documents = load_pdf(uploaded_file)

        chunks = create_chunks(documents)

        for chunk in chunks:
            chunk.metadata["filename"] = filename
            chunk.metadata["document_id"]=document_id
            chunk.metadata["conversation_id"]=conv_id

        vector_store.add_documents(chunks, namespace=conv_id)

        return {
            "success": True,
            "chunks_count": len(chunks)
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
