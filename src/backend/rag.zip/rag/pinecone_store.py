import os
from langchain_pinecone import PineconeVectorStore

from rag.embeddings import get_embeddings


def get_vector_store():
    embeddings= get_embeddings()
    vector_store= PineconeVectorStore(
         index_name= os.getenv("PINECONE_INDEX_NAME"),
         embedding=embeddings
    )

    return vector_store